import 'package:flutter/material.dart';
import './question.dart';
import './answer.dart';

void main() => runApp(TestApp());

class TestApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<TestApp> {
  String _question = 'Select a Question';
  var _questions = [
    {
      'question': 'What\'s your favorite color?',
      'answers': ['Black', 'White', 'Pink', 'Purple', 'Orange'],
    },
    {
      'question': 'What\'s your favorite pet?',
      'answers': ['Dog', 'Cat', 'Lizard'],
    },
    {
      'question': 'What\'s your mother\'s maiden name?',
      'answers': ['Johns', 'Hamilton', 'Johanson', 'Klein'],
    },
    {
      'question': 'Are you a Youtuber?',
      'answers': ['Go', 'Commit', 'Game', 'Over'],
    },
  ];
  Map<String, String> answers = Map();
  List<Widget> widgetList;

  _MyAppState() {
    widgetList = _initialColumnList();
  }

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('TestApp AppBar')),
        //Change the body to a completion if all questions have been answered using a "?" statement
        body: _questions.length > 0
            ? Column(
                children: widgetList,
              )
            : Container(
                width: double.infinity,
                margin: EdgeInsets.all(10),
                child: Text(
                  'Results:\n $answers',
                  style: TextStyle(fontSize: 28),
                  textAlign: TextAlign.center,
                )),
      ),
      debugShowCheckedModeBanner: false,
    );
  }

  List<Widget> _initialColumnList() {
    List<Widget> widgets = List<Widget>();
    widgets.add(Question(_question));

    _questions.asMap().forEach(
          (index, value) => widgets.add(Answer(
              function: () => _answerQuestion(index),
              answerName: value['question'])),
        );

    return widgets;
  }

  List<Widget> _questionListFromIndex(int i) {
    List<Widget> widgets = List<Widget>();

    widgets.add(Question(_question));

    (_questions[i]['answers'] as List<String>)
        .asMap()
        .forEach((index, value) => widgets.add(Answer(
              answerName: value,
              function: () {
                print('Answer executes button $index for question $i');
                answers[_questions[i]['question']] = value;
                _questions.remove(_questions[i]);

                setState(() {
                  _question = 'Select a Question';
                  widgetList = _initialColumnList();
                });
              },
            )));

    widgets.add(
      Answer(
        answerName: 'Go back',
        function: () {
          setState(() {
            _question = 'Select a Question';
            widgetList = _initialColumnList();
          });
        },
        color: Colors.blueAccent,
      ),
    );
    return widgets;
  }

  void _answerQuestion(int i) {
    setState(() {
      _question = _questions[i]['question'];
      widgetList = _questionListFromIndex(i);
    });
  }
}
