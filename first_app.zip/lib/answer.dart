import 'package:flutter/material.dart';

class Answer extends StatelessWidget {
  final Function function;
  final String answerName;
  final Color color;

  Answer({this.function, this.answerName, this.color = Colors.lightBlueAccent});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: RaisedButton(
          child: Text(answerName),
          onPressed: function,
          color: color),
          
    );
  }
}
